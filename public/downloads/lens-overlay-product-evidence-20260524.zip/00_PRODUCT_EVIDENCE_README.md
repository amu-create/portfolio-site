# LensOverlay Translate Product Evidence README

Updated: 2026-05-24

## Product status

LensOverlay Translate is an Android AI evaluation build. It demonstrates camera OCR, MediaProjection screen translation, overlay interaction, market-flavor routing, and release QA evidence. It is not a production-store release.

## What is verified

| Area | Evidence | Status |
| --- | --- | --- |
| Release build | China/Global release unit tests and assemble tasks | Verified |
| APK install | QA-signed China release APK installed on Medium_Phone_API_35 | Verified |
| Camera flow | Camera entry and capture-result sheet exercised | Verified |
| Screen translation | MediaProjection consent, floating bubble, result sheet, stop cleanup | Verified |
| APK integrity | apksigner, aapt, SHA-256 CSV | Verified |
| Secret exposure | APK scan for API key and bearer patterns | 0 hits |
| Release privacy | Release build no longer auto-saves source capture images | Improved |

## What is not verified yet

| Gate | Why it matters | Required next evidence |
| --- | --- | --- |
| Production signing | QA debug keystore is not acceptable for store or customer distribution | Organization release key, signing custody note, rollback plan |
| Physical-device matrix | Camera/overlay behavior can vary by OEM, orientation, memory pressure | Samsung and Pixel-class device recordings |
| China/provider latency | Translation provider path was not exercised with approved live keys | p50/p95 latency, timeout, fallback and error UX report |
| Durable server controls | Optional proxy secret and in-memory rate limit are not enterprise abuse controls | Mandatory auth, durable rate limit, audit trail |
| Data retention | Screen capture and OCR text can be sensitive | Customer-approved retention/deletion policy and privacy notice |

## Primary files

- Enterprise readiness: `07_enterprise-review/enterprise-readiness.md`
- Release APK verification: `05_evidence/release-apk-verification.md`
- Security review: `05_evidence/security-review.md`
- Privacy data map: `05_evidence/privacy-data-map.md`
- Known limitations and exit criteria: `05_evidence/known-limitations-and-exit-criteria.md`
- QA-signed APKs: `04_demo/release-qa/`

## Correct external phrasing

Use: `QA-signed release evaluation build with emulator release QA evidence.`

Do not use: `production ready`, `enterprise ready`, `store release`, `security complete`, `physical-device verified`, or `China latency verified`.
