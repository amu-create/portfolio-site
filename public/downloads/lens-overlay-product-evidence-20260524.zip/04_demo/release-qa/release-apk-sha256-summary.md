# Release APK SHA-256 Summary

Updated: 2026-05-24

## China flavor

- File: `LensOverlay-China-0.1.0-release-qa-signed.apk`
- SHA-256: `D5D8DBD5EAA7A575C55EF1DDDD651AFE3D7CD9872591959F41AE0E40C9651BD6`

## Global flavor

- File: `LensOverlay-Global-0.1.0-release-qa-signed.apk`
- SHA-256: `90EEBB2F0FB5E0D4DAFE6FBAED160C3D747AFFE6B154E56A5934B6F4A85BE181`

## Scope

These hashes identify the QA-signed release evaluation APKs. They do not imply production signing.
