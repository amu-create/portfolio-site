# Product Evidence Manifest

Updated: 2026-05-24

## Included in product evidence ZIP

- `00_PRODUCT_EVIDENCE_README.md`
- `00_PRODUCT_EVIDENCE_README.pdf`
- `PRODUCT_MANIFEST.md`
- `07_enterprise-review/enterprise-readiness.md`
- `07_enterprise-review/enterprise-readiness.pdf`
- `05_evidence/release-apk-verification.md`
- `05_evidence/release-apk-verification.pdf`
- `05_evidence/security-review.md`
- `05_evidence/security-review.pdf`
- `05_evidence/privacy-data-map.md`
- `05_evidence/privacy-data-map.pdf`
- `05_evidence/known-limitations-and-exit-criteria.md`
- `05_evidence/known-limitations-and-exit-criteria.pdf`
- `05_evidence/privacy-security-note.md`
- `05_evidence/privacy-security-note.pdf`
- `05_evidence/apk-secret-scan-summary.md`
- `04_demo/release-qa/release-apk-sha256-summary.md`
- `05_evidence/screenshots/release-qa/*.png`

## Excluded from product evidence ZIP

- legacy candidate/application documents,
- debug APK,
- APK binary files,
- internal generated build directories.

## Current status

LensOverlay Translate is a QA-signed release evaluation build with emulator release QA evidence. It is not a production-store release.
