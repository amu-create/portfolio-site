# Release APK Verification

Updated: 2026-05-24

## Primary APKs

| Flavor | Path | Scope |
| --- | --- | --- |
| China | `04_demo/release-qa/LensOverlay-China-0.1.0-release-qa-signed.apk` | Primary evaluation APK |
| Global | `04_demo/release-qa/LensOverlay-Global-0.1.0-release-qa-signed.apk` | Secondary flavor APK |

## Hashes

See `04_demo/release-qa/release_apk_sha256_20260523.csv`.

- China SHA-256: `D5D8DBD5EAA7A575C55EF1DDDD651AFE3D7CD9872591959F41AE0E40C9651BD6`
- Global SHA-256: `90EEBB2F0FB5E0D4DAFE6FBAED160C3D747AFFE6B154E56A5934B6F4A85BE181`

## Verification performed

- `:app:testChinaReleaseUnitTest`
- `:app:testGlobalReleaseUnitTest`
- `:app:assembleChinaRelease`
- `:app:assembleGlobalRelease`
- `zipalign`
- `apksigner sign`
- `apksigner verify`
- `aapt dump badging`
- APK secret scan for common API key and bearer token patterns

## Emulator smoke matrix

| Flow | Result | Evidence |
| --- | --- | --- |
| Launch | Pass | `05_evidence/screenshots/release-qa/01_launch_home.png` |
| Camera entry | Pass | `05_evidence/screenshots/release-qa/02_camera_entry.png` |
| Camera capture result | Pass, emulator scene had no useful text | `05_evidence/screenshots/release-qa/03_camera_capture_result.png` |
| MediaProjection consent | Pass | `05_evidence/screenshots/release-qa/05_screen_translate_projection_dialog.png` |
| Screen translate session | Pass | `05_evidence/screenshots/release-qa/06_screen_translate_after_consent.png` |
| Screen translate result | Pass, OCR output was noisy test data | `05_evidence/screenshots/release-qa/08_screen_translate_result.png` |
| Stop/cleanup | Pass | `05_evidence/screenshots/release-qa/10_screen_translate_after_stop_2.png` |

## Debug artifact boundary

`04_demo/LensOverlay-China-0.1.0-debug-demo.apk` is retained only for internal diagnostic comparison. It is not the primary external review artifact.
