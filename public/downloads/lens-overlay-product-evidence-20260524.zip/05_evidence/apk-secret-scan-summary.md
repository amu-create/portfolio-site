# APK Secret Scan Summary

Updated: 2026-05-24

## Result

APK scan found 0 hits for common upstream API key, bearer-token, and Google API key patterns.

## Patterns checked

- `OPENAI_API_KEY`
- `MINIMAX_API_KEY`
- `PROXY_SHARED_SECRET`
- `sk-*`
- `AIza*`
- `bearer`

## Scope

This scan is evidence for the reviewed APK artifacts only. It is not a complete source-code secret-management audit.
