# Known Limitations and Exit Criteria

Updated: 2026-05-24

## Do not claim

- Production-ready release
- Store distribution readiness
- Enterprise security completion
- China-network latency verification
- Physical-device verification
- Complete privacy compliance

## Exit criteria for next credible gate

| Gate | Exit criteria |
| --- | --- |
| Physical-device QA | 2 devices, camera/photo/screen flows, permission denial, orientation, low-memory, stop cleanup |
| Real-world OCR quality | At least 20 representative samples, pass/fail notes, failure taxonomy |
| Provider latency | p50/p95, timeout rate, fallback rate, retry behavior, user-visible error state |
| Production signing | Release-key process, artifact provenance, rollback package, signing verification |
| Server controls | Mandatory proxy auth, durable rate limit, audit log, abuse threshold |
| Privacy | Data map, retention/deletion policy, capture notice, log redaction |

## Current honest positioning

`LensOverlay Translate is an Android AI evaluation build with release-build QA evidence and explicit production blockers.`
