# Privacy Data Map

Updated: 2026-05-24

## Data classes

| Data | Source | Storage | Transmission | Current control |
| --- | --- | --- | --- | --- |
| Camera image | CameraX capture or gallery input | Release build does not auto-save diagnostic source image | May be processed for OCR/translation flow | Debug persistence disabled in release |
| Screen capture image | MediaProjection capture | Release build does not auto-save diagnostic source image | May be processed for OCR/translation flow | Debug persistence disabled in release |
| OCR text | ML Kit OCR output | Not claimed as durable storage | May be sent to selected translation provider/proxy | Provider path must be reviewed per market |
| Translation result | Provider/local output | UI result state | Returned to app UI | No production retention guarantee yet |
| Logs | App/server diagnostic logs | Evidence logs in package | Local evidence only | Production redaction/audit policy needed |

## Privacy claims allowed

- Allowed: release build no longer auto-saves source capture images for diagnostic evidence.
- Allowed: no upstream API key patterns were found in APK secret scan.
- Not allowed: complete privacy compliance, complete data deletion, enterprise DPA readiness.

## Next required policy

Before a production pilot, define:

- capture consent copy,
- OCR/translation text retention period,
- server log redaction fields,
- user deletion path,
- provider region and subprocessors,
- support/incident escalation path.
