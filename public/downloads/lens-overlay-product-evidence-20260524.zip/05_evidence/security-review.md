# Security Review

Updated: 2026-05-24

## Current security posture

This is an evaluation build. It demonstrates security-aware implementation discipline, but it does not claim enterprise production readiness.

## Implemented controls

- APK evidence scan did not find upstream API keys or bearer-token patterns.
- Release build no longer auto-saves source camera/screen capture images.
- China and Global provider paths are separated by product flavor.
- Production gaps are documented instead of hidden.

## Main threat areas

| Threat area | Risk | Current state | Required production control |
| --- | --- | --- | --- |
| Screen capture | Sensitive content may be captured during translation | Release no-auto-save fix applied | Explicit privacy notice, user-visible capture state, deletion policy |
| OCR text | OCR text may contain private data | Translation flow processes extracted text | Retention minimization, log redaction, deletion and customer policy |
| Remote provider | Text may leave device for translation | Provider routing exists | Provider DPA review, region policy, timeout/fallback report |
| Proxy abuse | Backend may be abused without durable controls | Shared secret/rate limit not enterprise-grade | Mandatory auth, durable rate limit, audit log |
| APK distribution | QA debug keystore is not production signing | QA-signed release build only | Release-key custody and distribution plan |

## Blockers before production pilot

- Mandatory proxy authentication and durable rate limiting.
- Redacted structured logs and audit trail.
- Documented incident response and abuse-control path.
- Formal data map and retention/deletion policy.
- Physical-device privacy QA for camera and screen-capture flows.
