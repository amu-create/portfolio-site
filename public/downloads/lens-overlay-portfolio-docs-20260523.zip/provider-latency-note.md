# Provider Latency Evidence Note

Date: 2026-05-23

## Current Status

A new live MiniMax/provider latency run was not executed in this session.

Reason:

- `MINIMAX_API_KEY` was not present in the current environment.
- `MINIMAX_BASE_URL` was not present.
- `PROXY_SHARED_SECRET` was not present.
- No local `.env*` file was found in the copied app/server roots.
- The standing project rule is not to run external paid API paths unless explicitly configured for the run.

## Existing Project Evidence

The copied source already contains prior QA notes:

- `01_working/lens-overlay-translate/docs/qa/MINIMAX_FAST_RUNTIME_QA.md`
- `01_working/lens-overlay-translate/docs/qa/MINIMAX_FAST_QUALITY_P1.md`
- `01_working/lens-overlay-translate/docs/qa/MINIMAX_FAST_PARSE_FIX_MANUAL_RETEST.md`

Representative historical values from those notes:

- Android runtime samples: `6732ms`, `10613ms`, `12461ms`
- Server-side samples: `6226ms`, `10285ms`, `11286ms`
- Quality P1 server QA: `p50=7738ms`, `p95=17077ms`
- Fallback count in those sampled runs: `0`

Treat these as existing project evidence, not a new 2026-05-23 live measurement.

## Safe Retest Command

Only run a new live provider test when the environment is intentionally configured:

```powershell
Set-Location "D:\Users\지원서\대기업_포트폴리오_번역앱_지원서_20260523_180727\01_working\lens-overlay-translate\server-vercel"
if (-not $env:MINIMAX_API_KEY) { throw "MINIMAX_API_KEY absent: do not run paid latency test." }
npm test
```

For an enterprise-ready package, record request count, provider, mode, p50 latency, p95 latency, timeout, fallback rate, cache hit rate, HTTP status/error code, and region/network context.
