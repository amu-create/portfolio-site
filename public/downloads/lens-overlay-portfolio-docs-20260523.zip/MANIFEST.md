# Package Manifest

Created: 2026-05-23
Root: D:\Users\지원서\대기업_포트폴리오_번역앱_지원서_20260523_180727
Originals copied only: yes
Primary portfolio: 01_전서기_번역앱_포트폴리오_대기업제출용.pdf
Primary application: 02_전서기_지원서_앱AI서비스_대기업용.pdf
Demo APK: 04_demo/LensOverlay-China-0.1.0-debug-demo.apk
Evidence summary: 05_evidence/evidence-summary.pdf
Source brief: 06_source-brief/architecture-summary.pdf
APK SHA-256: 031DD650F33A0E94CFE279F4F2CECA7A6E8B8519C67C7ED113C8455588B5AF3F

## 2026-05-23 Release QA Addendum

- Release QA evidence: `05_evidence/release-qa-addendum.pdf`
- Privacy/security note: `05_evidence/privacy-security-note.pdf`
- Provider latency note: `05_evidence/provider-latency-note.pdf`
- China QA-signed release APK: `04_demo/release-qa/LensOverlay-China-0.1.0-release-qa-signed.apk`
- Global QA-signed release APK: `04_demo/release-qa/LensOverlay-Global-0.1.0-release-qa-signed.apk`
- Release APK hashes: `04_demo/release-qa/release_apk_sha256_20260523.csv`
- APK secret scan: `05_evidence/apk_secret_scan_20260523.txt`
- Release QA screenshots: `05_evidence/screenshots/release-qa/`

Note: the release APKs are QA-signed with the local Android debug keystore for interview/demo installation evidence. They are not production store-signed builds.
