# LensOverlay Release QA Addendum

Date: 2026-05-23
Scope: copied working source only. The original portfolio/app sources were not modified.

## Executive Result

The package now contains installable QA-signed release APKs for both market flavors, not only the earlier debug demo APK.

- China release QA APK: `04_demo/release-qa/LensOverlay-China-0.1.0-release-qa-signed.apk`
- Global release QA APK: `04_demo/release-qa/LensOverlay-Global-0.1.0-release-qa-signed.apk`
- Signing status: `apksigner verify --verbose --print-certs` passed for both APKs.
- App metadata: `aapt dump badging` passed for both APKs through an ASCII temp path.
- Secret scan: 0 hits for `OPENAI_API_KEY`, `MINIMAX_API_KEY`, `PROXY_SHARED_SECRET`, `sk-*`, `AIza*`, and bearer-token patterns.

This is QA signing with the local Android debug keystore. It is suitable for interview/demo installation evidence, not production store distribution.

## Release APK Hashes

See: `04_demo/release-qa/release_apk_sha256_20260523.csv`

- China SHA-256: `D5D8DBD5EAA7A575C55EF1DDDD651AFE3D7CD9872591959F41AE0E40C9651BD6`
- Global SHA-256: `90EEBB2F0FB5E0D4DAFE6FBAED160C3D747AFFE6B154E56A5934B6F4A85BE181`

## Build Verification

Command run from copied source:

```powershell
$env:JAVA_HOME='C:\Program Files\Eclipse Adoptium\jdk-17.0.16.8-hotspot'
$env:GRADLE_OPTS='-Djavax.net.ssl.trustStoreType=WINDOWS-ROOT'
.\gradlew.bat :app:testChinaReleaseUnitTest :app:testGlobalReleaseUnitTest :app:assembleChinaRelease :app:assembleGlobalRelease --no-daemon
```

Result: `BUILD SUCCESSFUL`.

Evidence:

- `03_evidence/release_qa/gradle_release_build_20260523.log`
- `03_evidence/release_qa/china_apksigner_verify_20260523.log`
- `03_evidence/release_qa/global_apksigner_verify_20260523.log`
- `03_evidence/release_qa/china_aapt_badging_20260523.log`
- `03_evidence/release_qa/global_aapt_badging_20260523.log`
- `05_evidence/apk_secret_scan_20260523.txt`

## Emulator QA

Device: `Medium_Phone_API_35`, `emulator-5554`, API 35.
Package tested: `com.lensoverlay.translate.china`, version `0.1.0-china`.

Passed flows:

- Install and launch: PASS. `MainActivity` focused with no high-severity crash hits.
- Home UI smoke: PASS. Screenshot: `05_evidence/screenshots/release-qa/01_launch_home.png`.
- Camera entry: PASS. Camera preview rendered. Screenshot: `05_evidence/screenshots/release-qa/02_camera_entry.png`.
- Camera capture/OCR: PASS. The emulator scene had no Chinese text, so result count was 0; no crash or permission failure. Screenshot: `05_evidence/screenshots/release-qa/03_camera_capture_result.png`.
- Screen translate setup: PASS. Overlay app-op allowed and privacy mode visible/on. Screenshot: `05_evidence/screenshots/release-qa/06_screen_translate_after_consent.png`.
- MediaProjection consent: PASS. System consent dialog appeared for LensOverlay China. Screenshot: `05_evidence/screenshots/release-qa/05_screen_translate_projection_dialog.png`.
- Screen translate capture: PASS. Floating button triggered screen capture, OCR, translation, and result sheet. Screenshot: `05_evidence/screenshots/release-qa/08_screen_translate_result.png`.
- Screen translate stop: PASS. Session stopped, virtual display removed, floating bubble stopped. Screenshot: `05_evidence/screenshots/release-qa/10_screen_translate_after_stop_2.png`.

Release privacy check:

- After camera capture and screen capture, `/sdcard/Android/data/com.lensoverlay.translate.china/files` had no app-created image files.
- Log signal showed `sourceImageSaved=false` during screen translate release execution.

## Remaining Blockers

- Physical Android phone QA: BLOCKED. `adb devices -l` returned no physical device.
- Real camera/OEM overlay behavior: BLOCKED until a physical device is connected.
- China network/provider latency: BLOCKED for a new paid live run because local `MINIMAX_API_KEY`, `MINIMAX_BASE_URL`, `PROXY_SHARED_SECRET`, and `LENS_SERVER_TRANSLATION_BASE_URL` are not configured in this environment.

## Honest Enterprise Positioning

This package can be described as a release-build QA demo with emulator-verified install, launch, camera, MediaProjection, overlay, stop-cleanup, signing, metadata, and secret-scan evidence.

It should not be described as production-store ready until production signing, physical-device QA, crash/performance telemetry, proxy abuse protection, and region-network latency evidence are completed.
