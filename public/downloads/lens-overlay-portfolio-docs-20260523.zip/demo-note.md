# Demo APK 안내

- 파일: `LensOverlay-China-0.1.0-debug-demo.apk`
- package: `com.lensoverlay.translate.china`
- versionName: `0.1.0-china`
- 용도: 면접/기술검증용 debug demo

## 확인된 실행 환경

- Medium_Phone_API_35
- emulator-5554
- Android SDK 35
- install Success
- MainActivity launch/focus 확인

## 주의

이 APK는 제출 패키지에 포함된 검증용 복사본입니다. 상용 배포용 release APK가 아닙니다. 대외 배포 전에는 release signing, debug UI 제거 확인, 개인정보 안내, 실제 기기 QA, crash/performance telemetry 확인이 필요합니다.
