# LensOverlay Translate 제출 증거 요약

## 검증 날짜

- 2026-05-23

## 대상 APK

- 원본 복사본: `00_original_copies/apk/app-china-debug.apk`
- 제출용 데모 복사본: `02_portfolio_package/04_demo/LensOverlay-China-0.1.0-debug-demo.apk`
- SHA-256: `031DD650F33A0E94CFE279F4F2CECA7A6E8B8519C67C7ED113C8455588B5AF3F`

## APK 메타데이터

- package: `com.lensoverlay.translate.china`
- versionCode: `1`
- versionName: `0.1.0-china`
- minSdk: `23`
- targetSdk: `35`
- 주요 권한: CAMERA, INTERNET, SYSTEM_ALERT_WINDOW, FOREGROUND_SERVICE, FOREGROUND_SERVICE_MEDIA_PROJECTION, POST_NOTIFICATIONS, ACCESS_NETWORK_STATE

## 실행 검증

| 검증 | 결과 | 증거 파일 |
|---|---:|---|
| 원본 APK SHA 보존 | PASS | `03_evidence/qa/apk_smoke_20260523.log` |
| 설치 | PASS | install Success |
| 실행 | PASS | monkey launch, MainActivity focus |
| 화면 | PASS | `03_evidence/screenshots/01_china_launch_home.png` |
| UI 구조 | PASS | `03_evidence/qa/uiautomator_home.xml` |
| 패키지 정보 | PASS | `03_evidence/qa/dumpsys_package_china.txt` |
| 크래시/ANR | PASS* | `03_evidence/qa/logcat_lens_filtered.txt` |

`PASS*`: logcat에서 앱 FATAL/ANR은 보이지 않았습니다. GoogleApiManager의 emulator 환경 noise는 있었지만 `com.lensoverlay.translate.china` 앱 크래시로 판단하지 않았습니다.

## 빌드/테스트 검증

복사본 소스에서 아래 검증을 실행했습니다. 원본 프로젝트와 원본 지원서 폴더는 수정하지 않았습니다.

```powershell
$env:JAVA_HOME='C:\Program Files\Eclipse Adoptium\jdk-17.0.16.8-hotspot'
$env:GRADLE_OPTS='-Djavax.net.ssl.trustStoreType=WINDOWS-ROOT'
.\gradlew.bat :app:testChinaDebugUnitTest :app:assembleChinaDebug
```

결과: exit code 0. 복사본 APK 생성 확인: `01_working/lens-overlay-translate/app/build/outputs/apk/china/debug/app-china-debug.apk`.

## 제출 시 말하면 좋은 범위

강하게 말해도 되는 것:

- targetSdk 35 기준의 Android 앱으로 package install/run 증거를 남겼다.
- 카메라/사진/화면 위 번역이라는 세 가지 실사용 흐름을 하나의 앱 첫 화면에 정리했다.
- ML Kit OCR/Translate, MediaProjection, Overlay Service, flavor 분리, 서버 프록시 경계를 사용했다.
- API key를 Android 앱에 넣지 않는 설계를 우선했다.
- QA evidence를 별도 폴더로 남겨 면접관이 검증 흐름을 따라갈 수 있게 했다.

아직 과장하면 안 되는 것:

- 상용 배포 완료라고 말하면 안 됩니다. 현재 제출 APK는 debug demo입니다.
- 중국 현지망에서 검증 완료라고 말하면 안 됩니다. 별도 실측이 필요합니다.
- 실제 물리폰 카메라 품질 검증 완료라고 말하면 안 됩니다. 실제 기기 테스트가 필요합니다.
- 개인정보/보안 완전 충족이라고 말하면 안 됩니다. 출시 전 로그/캐시/서버 인증/요금 제한 검토가 필요합니다.
