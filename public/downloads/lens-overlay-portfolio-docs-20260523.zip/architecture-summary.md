# LensOverlay Translate 소스 브리프

## 목적

이 문서는 면접관이 전체 소스를 열지 않아도 핵심 구조를 빠르게 파악하도록 만든 요약입니다.

## 기술 스택

- Kotlin / Android
- Jetpack Compose / Material 3 계열 UI
- CameraX
- Android MediaProjection / Foreground Service / Overlay Service
- ML Kit OCR / ML Kit Translate
- Gradle product flavor: `global`, `china`
- Vercel server proxy 경로

## 주요 구조

```text
app/src/main/java/com/lensoverlay/translate
  MainActivity.kt
  TranslationViewModel.kt
  data/capture/ScreenCaptureRequestActivity.kt
  data/capture/ScreenCaptureForegroundService.kt
  data/overlay/OverlayBubbleService.kt
  data/ocr/MlKitOcrEngine.kt
  data/provider/TranslationRouter.kt
  data/translation/MlKitTranslationEngine.kt
  data/translation/RemoteTranslationClient.kt
  domain/usecase/TranslateOcrBlocksUseCase.kt
  domain/usecase/ImageTranslationCompositor.kt
  ui/home/HomeScreen.kt
  ui/camera/CameraScreen.kt
  ui/screen/ScreenTranslateScreen.kt
```

## 읽는 순서

1. `ui/home/HomeScreen.kt`: 사용자에게 보이는 첫 행동 구조를 확인합니다.
2. `MainActivity.kt`: 홈, 카메라, 이미지, 화면 번역의 라우팅을 확인합니다.
3. `TranslationViewModel.kt`: OCR/번역/상태 전환의 중심 흐름을 확인합니다.
4. `data/capture/*`: MediaProjection 동의, foreground service, 세션 종료 구조를 확인합니다.
5. `data/overlay/OverlayBubbleService.kt`: 화면 위 플로팅 번역 UX를 확인합니다.
6. `data/ocr/MlKitOcrEngine.kt`: 다국어 OCR 엔진 구성을 확인합니다.
7. `data/provider/TranslationRouter.kt`: provider/flavor 분리 기준을 확인합니다.

## 남은 리팩터링 후보

- `TranslationViewModel.kt`와 `CameraScreen.kt`는 기능이 많이 모인 편이라 usecase/state reducer 단위로 더 나눌 수 있습니다.
- 화면 캡처 결과 캐시와 debug output은 출시 전 저장 위치/수명/마스킹 기준을 별도 정책으로 내려야 합니다.
- remote proxy는 인증, rate limit, timeout, 비용 제한, 장애 fallback을 더 명확히 해야 합니다.
